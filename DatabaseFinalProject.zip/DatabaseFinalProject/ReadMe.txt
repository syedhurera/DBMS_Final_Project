////////// ReadMe File /////////////

What it is about?

This is a Semester Final Project in which we are createing a GUI based Restaurant Management
System.This a Database Project which is done by using MS Access and java connectivity using
java IDE Netbeans.We have used different queries and relationships to get it operational.
 
Project Demonstration:

We have created a Restaurent Management System in which we first take information for sign up from 
customers. After sign up one can sign in through given username and password. Administration can also
sign in from their specific given username and password. Word 'Admin' is restricted for all
Admins. There are two different interfaces for both customers and Admins. Admins can add and remove
employee and they can also have a look on daily orders and feedbacks. On other hand, we have 
choice for dinn in and delivery of orders.In Menu we have different food items. Customer can place
order and also we have different payment methods. And In the last, we are taking reviews of Customers.

Here is link of our video demonstration...
https://drive.google.com/file/d/11AaP2uc8cfuu6VjcdJTKOtJWCRgSvxy3/view?usp=sharing

Group Members:
Danish Hafeez (021-19-0003)
Syed Hurera (021-19-0040)
Shaharyar (021-19-0037)
